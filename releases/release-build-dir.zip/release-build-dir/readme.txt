How to use this application:
Start the application by running "node photo-metadata-updater" from this directory in a console
	- You need to add your BING API key to the config.properties file first, and the path to exiftool on your system

Use the application as follows:
1. Enter full system path to the directory of photos you wish to edit in the text box in the header, then press Enter
2. All JPG and/or PNG images will load into the list on the side bar
3. Select a photo from the list to view the photo, a map of where it was taken, and the photo metadata
4. Edit the metadata as needed, these fields include:
    - Date: Local date from when the photo was taken
    - Time: Local time from when the photo was taken - *NOT UTC Time*
    - Timezone Offset: The timezone offset between the local time and UTC time
        * (e.g. Hawaii offset is -10 hours, and it is written as *-1000* using `+/-HHMM` notation)
    - Elevation: Elevation in meters of where photo was taken (negative or positive, including decimal values)
    - Latitude: GPS latitude of where the photo was taken
    - Longitude: GPS longitude of where the photo was taken
6. Click 'Save' to save the metadata

Tip 1: Click the search icon next to timezone offset field to calculate timezone offset based on the GPS and date/time information

Tip 2: You can either click on the map itself to select new coordinates, or enter them manually in the text boxes

Tip 3: You can toggle the options button in the top left to enable these options:
	- Toggle dark mode on/off
	- Toggle on/off the warning message that appears before saving a photo
	- Toggle on/off the tooltip that appears when you hover over the timezone calculate button